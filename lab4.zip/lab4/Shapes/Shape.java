package Shapes;
public interface Shape {
    
    double[] getSideLengths();
    double getArea();

}
